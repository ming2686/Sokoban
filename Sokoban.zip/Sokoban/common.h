#ifndef _common_h
#define _common_h

#include <stdio.h>
#include <stdlib.h>

extern char originstage[18][21];
extern char playstage[18][21];
extern int nx, ny;
extern int dx, dy;
extern int cursorLocation;

#endif
