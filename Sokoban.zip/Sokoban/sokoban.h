#ifndef _sokoban_h
#define _sokoban_h
#include "common.h"

void initial();

void show();
void showstage();

void charactersetting();
void charactermove(int, int);

void showgamestop();

#endif

